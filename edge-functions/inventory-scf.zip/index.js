const { Hono } = require('hono');
const { handle } = require('hono/aws-lambda');

// 导入我们的应用
const app = require('./app');

// 腾讯云函数入口
exports.main_handler = async (event, context) => {
    // 转换腾讯云函数事件为标准HTTP请求
    const request = {
        method: event.httpMethod || 'GET',
        url: event.path || '/',
        headers: event.headers || {},
        body: event.body || ''
    };
    
    return await handle(app)(request, context);
};
