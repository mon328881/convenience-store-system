// 本地测试腾讯云函数
const { main_handler } = require('./index.js');

// 模拟腾讯云函数事件
const testEvent = {
    httpMethod: 'GET',
    path: '/api/health',
    headers: {
        'Content-Type': 'application/json'
    },
    body: ''
};

const testContext = {
    requestId: 'test-request-id'
};

console.log('开始测试腾讯云函数...');

main_handler(testEvent, testContext)
    .then(result => {
        console.log('函数执行成功:');
        console.log(JSON.stringify(result, null, 2));
    })
    .catch(error => {
        console.error('函数执行失败:', error);
    });