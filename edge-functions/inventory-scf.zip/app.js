const { Hono } = require('hono');
const { cors } = require('hono/cors');
const mongoose = require('mongoose');

const app = new Hono();

// CORS配置
app.use('*', cors({
    origin: ['http://localhost:3000', 'https://*.edgeone.app', 'https://*.pages.dev'],
    allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowHeaders: ['Content-Type', 'Authorization'],
    credentials: true
}));

// MongoDB连接
let isConnected = false;

const connectDB = async () => {
    if (isConnected) return;
    
    try {
        await mongoose.connect(process.env.MONGODB_URI, {
            useNewUrlParser: true,
            useUnifiedTopology: true,
            maxPoolSize: 5,
            serverSelectionTimeoutMS: 5000,
            socketTimeoutMS: 45000,
        });
        isConnected = true;
        console.log('MongoDB连接成功');
    } catch (error) {
        console.error('MongoDB连接失败:', error);
        throw error;
    }
};

// 数据模型
const ProductSchema = new mongoose.Schema({
    name: { type: String, required: true },
    category: { type: String, required: true },
    price: { type: Number, required: true },
    stock: { type: Number, default: 0 },
    minStock: { type: Number, default: 10 },
    supplier: { type: String, required: true },
    barcode: String,
    description: String,
    createdAt: { type: Date, default: Date.now },
    updatedAt: { type: Date, default: Date.now }
});

const SupplierSchema = new mongoose.Schema({
    name: { type: String, required: true },
    contact: { type: String, required: true },
    phone: String,
    email: String,
    address: String,
    createdAt: { type: Date, default: Date.now }
});

const InboundSchema = new mongoose.Schema({
    productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
    quantity: { type: Number, required: true },
    unitPrice: { type: Number, required: true },
    totalPrice: { type: Number, required: true },
    supplier: { type: String, required: true },
    date: { type: Date, default: Date.now },
    notes: String
});

const OutboundSchema = new mongoose.Schema({
    productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
    quantity: { type: Number, required: true },
    unitPrice: { type: Number, required: true },
    totalPrice: { type: Number, required: true },
    customer: String,
    date: { type: Date, default: Date.now },
    notes: String
});

// 中间件：确保数据库连接
app.use('*', async (c, next) => {
    await connectDB();
    await next();
});

// 健康检查
app.get('/api/health', (c) => {
    return c.json({
        status: 'ok',
        message: '库存管理系统API运行正常',
        timestamp: new Date().toISOString(),
        environment: 'Tencent Cloud Function'
    });
});

// 商品管理路由
app.get('/api/products', async (c) => {
    try {
        const Product = mongoose.model('Product', ProductSchema);
        const products = await Product.find().sort({ createdAt: -1 });
        return c.json({ success: true, data: products });
    } catch (error) {
        return c.json({ success: false, error: error.message }, 500);
    }
});

app.post('/api/products', async (c) => {
    try {
        const Product = mongoose.model('Product', ProductSchema);
        const data = await c.req.json();
        const product = new Product(data);
        await product.save();
        return c.json({ success: true, data: product }, 201);
    } catch (error) {
        return c.json({ success: false, error: error.message }, 400);
    }
});

// 供应商管理路由
app.get('/api/suppliers', async (c) => {
    try {
        const Supplier = mongoose.model('Supplier', SupplierSchema);
        const suppliers = await Supplier.find().sort({ createdAt: -1 });
        return c.json({ success: true, data: suppliers });
    } catch (error) {
        return c.json({ success: false, error: error.message }, 500);
    }
});

app.post('/api/suppliers', async (c) => {
    try {
        const Supplier = mongoose.model('Supplier', SupplierSchema);
        const data = await c.req.json();
        const supplier = new Supplier(data);
        await supplier.save();
        return c.json({ success: true, data: supplier }, 201);
    } catch (error) {
        return c.json({ success: false, error: error.message }, 400);
    }
});

// 入库管理路由
app.get('/api/inbound', async (c) => {
    try {
        const Inbound = mongoose.model('Inbound', InboundSchema);
        const records = await Inbound.find().populate('productId').sort({ date: -1 });
        return c.json({ success: true, data: records });
    } catch (error) {
        return c.json({ success: false, error: error.message }, 500);
    }
});

app.post('/api/inbound', async (c) => {
    try {
        const Inbound = mongoose.model('Inbound', InboundSchema);
        const Product = mongoose.model('Product', ProductSchema);
        
        const data = await c.req.json();
        const record = new Inbound(data);
        await record.save();
        
        // 更新商品库存
        await Product.findByIdAndUpdate(
            data.productId,
            { $inc: { stock: data.quantity } }
        );
        
        return c.json({ success: true, data: record }, 201);
    } catch (error) {
        return c.json({ success: false, error: error.message }, 400);
    }
});

// 出库管理路由
app.get('/api/outbound', async (c) => {
    try {
        const Outbound = mongoose.model('Outbound', OutboundSchema);
        const records = await Outbound.find().populate('productId').sort({ date: -1 });
        return c.json({ success: true, data: records });
    } catch (error) {
        return c.json({ success: false, error: error.message }, 500);
    }
});

app.post('/api/outbound', async (c) => {
    try {
        const Outbound = mongoose.model('Outbound', OutboundSchema);
        const Product = mongoose.model('Product', ProductSchema);
        
        const data = await c.req.json();
        
        // 检查库存
        const product = await Product.findById(data.productId);
        if (!product || product.stock < data.quantity) {
            return c.json({ success: false, error: '库存不足' }, 400);
        }
        
        const record = new Outbound(data);
        await record.save();
        
        // 更新商品库存
        await Product.findByIdAndUpdate(
            data.productId,
            { $inc: { stock: -data.quantity } }
        );
        
        return c.json({ success: true, data: record }, 201);
    } catch (error) {
        return c.json({ success: false, error: error.message }, 400);
    }
});

// 报表路由
app.get('/api/reports/summary', async (c) => {
    try {
        const Product = mongoose.model('Product', ProductSchema);
        const Inbound = mongoose.model('Inbound', InboundSchema);
        const Outbound = mongoose.model('Outbound', OutboundSchema);
        
        const totalProducts = await Product.countDocuments();
        const lowStockProducts = await Product.countDocuments({
            $expr: { $lt: ['$stock', '$minStock'] }
        });
        
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        const todayInbound = await Inbound.countDocuments({ date: { $gte: today } });
        const todayOutbound = await Outbound.countDocuments({ date: { $gte: today } });
        
        return c.json({
            success: true,
            data: {
                totalProducts,
                lowStockProducts,
                todayInbound,
                todayOutbound
            }
        });
    } catch (error) {
        return c.json({ success: false, error: error.message }, 500);
    }
});

// 404处理
app.notFound((c) => {
    return c.json({ success: false, error: 'API端点未找到' }, 404);
});

// 错误处理
app.onError((error, c) => {
    console.error('API错误:', error);
    return c.json({ success: false, error: '服务器内部错误' }, 500);
});

module.exports = app;
