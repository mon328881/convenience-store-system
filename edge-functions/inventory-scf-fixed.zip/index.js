const { Hono } = require('hono');
const { cors } = require('hono/cors');
const { logger } = require('hono/logger');
const mongoose = require('mongoose');

// 创建Hono应用实例
const app = new Hono();

// 中间件配置
app.use('*', logger());
app.use('*', cors({
  origin: ['https://*.edgeone.app', 'https://localhost:5173', 'http://localhost:5173'],
  allowMethods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
  allowHeaders: ['Content-Type', 'Authorization'],
  credentials: true
}));

// MongoDB连接管理
let isConnected = false;

const connectDB = async () => {
  if (isConnected && mongoose.connection.readyState === 1) {
    return;
  }
  
  try {
    await mongoose.connect(process.env.MONGODB_URI, {
      useNewUrlParser: true,
      useUnifiedTopology: true,
      maxPoolSize: 5, // 边缘函数使用较小的连接池
      serverSelectionTimeoutMS: 3000,
      socketTimeoutMS: 30000,
      bufferCommands: false,
    });
    isConnected = true;
    console.log('MongoDB连接成功');
  } catch (error) {
    console.error('MongoDB连接失败:', error);
    throw error;
  }
};

// 数据模型定义
const productSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  code: { type: String, required: true, unique: true, trim: true },
  category: { type: String, required: true, trim: true },
  unit: { type: String, required: true, trim: true },
  purchasePrice: { type: Number, required: true, min: 0 },
  salePrice: { type: Number, required: true, min: 0 },
  stock: { type: Number, default: 0, min: 0 },
  minStock: { type: Number, default: 0, min: 0 },
  maxStock: { type: Number, default: 1000, min: 0 },
  supplierId: { type: mongoose.Schema.Types.ObjectId, ref: 'Supplier', required: true },
  description: { type: String, maxlength: 500 },
  status: { type: String, enum: ['active', 'inactive'], default: 'active' }
}, { timestamps: true });

const supplierSchema = new mongoose.Schema({
  name: { type: String, required: true, trim: true },
  code: { type: String, required: true, unique: true, trim: true },
  contact: { type: String, required: true, trim: true },
  phone: { type: String, required: true, trim: true },
  email: { type: String, trim: true },
  address: { type: String, trim: true },
  status: { type: String, enum: ['active', 'inactive'], default: 'active' }
}, { timestamps: true });

const inboundSchema = new mongoose.Schema({
  inboundNumber: { type: String, required: true, unique: true },
  productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
  supplierId: { type: mongoose.Schema.Types.ObjectId, ref: 'Supplier', required: true },
  quantity: { type: Number, required: true, min: 1 },
  unitPrice: { type: Number, required: true, min: 0 },
  totalAmount: { type: Number, required: true, min: 0 },
  inboundDate: { type: Date, required: true },
  inboundType: { type: String, enum: ['purchase', 'return', 'transfer'], default: 'purchase' },
  status: { type: String, enum: ['pending', 'completed', 'cancelled'], default: 'pending' },
  remark: { type: String, maxlength: 500 }
}, { timestamps: true });

const outboundSchema = new mongoose.Schema({
  outboundNumber: { type: String, required: true, unique: true },
  productId: { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
  quantity: { type: Number, required: true, min: 1 },
  unitPrice: { type: Number, required: true, min: 0 },
  totalAmount: { type: Number, required: true, min: 0 },
  outboundDate: { type: Date, required: true },
  outboundType: { type: String, enum: ['sale', 'return', 'transfer', 'loss'], default: 'sale' },
  status: { type: String, enum: ['pending', 'completed', 'cancelled'], default: 'pending' },
  remark: { type: String, maxlength: 500 }
}, { timestamps: true });

// 注册模型
const Product = mongoose.models.Product || mongoose.model('Product', productSchema);
const Supplier = mongoose.models.Supplier || mongoose.model('Supplier', supplierSchema);
const Inbound = mongoose.models.Inbound || mongoose.model('Inbound', inboundSchema);
const Outbound = mongoose.models.Outbound || mongoose.model('Outbound', outboundSchema);

// 性能监控中间件
app.use('*', async (c, next) => {
  const start = Date.now();
  await next();
  const duration = Date.now() - start;
  console.log(`${c.req.method} ${c.req.url} - ${c.res.status} - ${duration}ms`);
});

// 健康检查
app.get('/health', (c) => {
  return c.json({ 
    status: 'OK', 
    timestamp: new Date().toISOString(),
    service: 'EdgeOne边缘函数',
    mongodb: mongoose.connection.readyState === 1 ? 'connected' : 'disconnected'
  });
});

// 认证路由
app.post('/api/auth/login', async (c) => {
  return c.json({
    success: true,
    message: '登录成功',
    data: {
      token: 'mock_token_' + Date.now(),
      user: { username: 'admin', role: 'admin' }
    }
  });
});

// 供应商路由
app.get('/api/suppliers', async (c) => {
  try {
    await connectDB();
    
    const { page = 1, limit = 10, search, status } = c.req.query();
    const query = {};
    
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { code: { $regex: search, $options: 'i' } }
      ];
    }
    
    if (status) {
      query.status = status;
    }
    
    const skip = (parseInt(page) - 1) * parseInt(limit);
    
    const [suppliers, total] = await Promise.all([
      Supplier.find(query).sort({ createdAt: -1 }).skip(skip).limit(parseInt(limit)).lean(),
      Supplier.countDocuments(query)
    ]);
    
    return c.json({
      success: true,
      data: suppliers,
      pagination: {
        current: parseInt(page),
        total,
        pages: Math.ceil(total / parseInt(limit))
      }
    });
  } catch (error) {
    console.error('获取供应商列表失败:', error);
    return c.json({ success: false, message: error.message }, 500);
  }
});

app.post('/api/suppliers', async (c) => {
  try {
    await connectDB();
    
    const supplierData = await c.req.json();
    
    // 检查供应商编码是否已存在
    const existingSupplier = await Supplier.findOne({ code: supplierData.code });
    if (existingSupplier) {
      return c.json({ success: false, message: '供应商编码已存在' }, 400);
    }
    
    const supplier = new Supplier(supplierData);
    await supplier.save();
    
    return c.json({
      success: true,
      message: '供应商创建成功',
      data: supplier
    }, 201);
  } catch (error) {
    console.error('创建供应商失败:', error);
    return c.json({ success: false, message: error.message }, 500);
  }
});

// 商品路由
app.get('/api/products', async (c) => {
  try {
    await connectDB();
    
    const { page = 1, limit = 10, search, category, status } = c.req.query();
    const query = {};
    
    if (search) {
      query.$or = [
        { name: { $regex: search, $options: 'i' } },
        { code: { $regex: search, $options: 'i' } }
      ];
    }
    
    if (category) {
      query.category = category;
    }
    
    if (status) {
      query.status = status;
    }
    
    const skip = (parseInt(page) - 1) * parseInt(limit);
    
    const [products, total] = await Promise.all([
      Product.find(query)
        .populate('supplierId', 'name')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(parseInt(limit))
        .lean(),
      Product.countDocuments(query)
    ]);
    
    return c.json({
      success: true,
      data: products,
      pagination: {
        current: parseInt(page),
        total,
        pages: Math.ceil(total / parseInt(limit))
      }
    });
  } catch (error) {
    console.error('获取商品列表失败:', error);
    return c.json({ success: false, message: error.message }, 500);
  }
});

app.post('/api/products', async (c) => {
  try {
    await connectDB();
    
    const productData = await c.req.json();
    
    // 检查商品编码是否已存在
    const existingProduct = await Product.findOne({ code: productData.code });
    if (existingProduct) {
      return c.json({ success: false, message: '商品编码已存在' }, 400);
    }
    
    // 检查供应商是否存在
    const supplier = await Supplier.findById(productData.supplierId);
    if (!supplier) {
      return c.json({ success: false, message: '供应商不存在' }, 400);
    }
    
    const product = new Product(productData);
    await product.save();
    
    await product.populate('supplierId', 'name');
    
    return c.json({
      success: true,
      message: '商品创建成功',
      data: product
    }, 201);
  } catch (error) {
    console.error('创建商品失败:', error);
    return c.json({ success: false, message: error.message }, 500);
  }
});

// 入库路由
app.get('/api/inbound', async (c) => {
  try {
    await connectDB();
    
    const { page = 1, limit = 10, search, status, startDate, endDate } = c.req.query();
    const query = {};
    
    if (search) {
      query.inboundNumber = { $regex: search, $options: 'i' };
    }
    
    if (status) {
      query.status = status;
    }
    
    if (startDate && endDate) {
      query.inboundDate = {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      };
    }
    
    const skip = (parseInt(page) - 1) * parseInt(limit);
    
    const [inbounds, total] = await Promise.all([
      Inbound.find(query)
        .populate('productId', 'name code')
        .populate('supplierId', 'name')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(parseInt(limit))
        .lean(),
      Inbound.countDocuments(query)
    ]);
    
    return c.json({
      success: true,
      data: inbounds,
      pagination: {
        current: parseInt(page),
        total,
        pages: Math.ceil(total / parseInt(limit))
      }
    });
  } catch (error) {
    console.error('获取入库记录失败:', error);
    return c.json({ success: false, message: error.message }, 500);
  }
});

app.post('/api/inbound', async (c) => {
  try {
    await connectDB();
    
    const inboundData = await c.req.json();
    
    // 生成入库单号
    const timestamp = Date.now();
    inboundData.inboundNumber = `IN${timestamp}`;
    
    // 计算总金额
    inboundData.totalAmount = inboundData.quantity * inboundData.unitPrice;
    
    const inbound = new Inbound(inboundData);
    await inbound.save();
    
    // 更新商品库存
    if (inbound.status === 'completed') {
      await Product.findByIdAndUpdate(
        inbound.productId,
        { $inc: { stock: inbound.quantity } }
      );
    }
    
    await inbound.populate(['productId', 'supplierId']);
    
    return c.json({
      success: true,
      message: '入库记录创建成功',
      data: inbound
    }, 201);
  } catch (error) {
    console.error('创建入库记录失败:', error);
    return c.json({ success: false, message: error.message }, 500);
  }
});

// 出库路由
app.get('/api/outbound', async (c) => {
  try {
    await connectDB();
    
    const { page = 1, limit = 10, search, status, startDate, endDate } = c.req.query();
    const query = {};
    
    if (search) {
      query.outboundNumber = { $regex: search, $options: 'i' };
    }
    
    if (status) {
      query.status = status;
    }
    
    if (startDate && endDate) {
      query.outboundDate = {
        $gte: new Date(startDate),
        $lte: new Date(endDate)
      };
    }
    
    const skip = (parseInt(page) - 1) * parseInt(limit);
    
    const [outbounds, total] = await Promise.all([
      Outbound.find(query)
        .populate('productId', 'name code')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(parseInt(limit))
        .lean(),
      Outbound.countDocuments(query)
    ]);
    
    return c.json({
      success: true,
      data: outbounds,
      pagination: {
        current: parseInt(page),
        total,
        pages: Math.ceil(total / parseInt(limit))
      }
    });
  } catch (error) {
    console.error('获取出库记录失败:', error);
    return c.json({ success: false, message: error.message }, 500);
  }
});

app.post('/api/outbound', async (c) => {
  try {
    await connectDB();
    
    const outboundData = await c.req.json();
    
    // 生成出库单号
    const timestamp = Date.now();
    outboundData.outboundNumber = `OUT${timestamp}`;
    
    // 计算总金额
    outboundData.totalAmount = outboundData.quantity * outboundData.unitPrice;
    
    // 检查库存
    const product = await Product.findById(outboundData.productId);
    if (!product) {
      return c.json({ success: false, message: '商品不存在' }, 400);
    }
    
    if (product.stock < outboundData.quantity) {
      return c.json({ success: false, message: '库存不足' }, 400);
    }
    
    const outbound = new Outbound(outboundData);
    await outbound.save();
    
    // 更新商品库存
    if (outbound.status === 'completed') {
      await Product.findByIdAndUpdate(
        outbound.productId,
        { $inc: { stock: -outbound.quantity } }
      );
    }
    
    await outbound.populate('productId');
    
    return c.json({
      success: true,
      message: '出库记录创建成功',
      data: outbound
    }, 201);
  } catch (error) {
    console.error('创建出库记录失败:', error);
    return c.json({ success: false, message: error.message }, 500);
  }
});

// 报表路由
app.get('/api/reports/dashboard', async (c) => {
  try {
    await connectDB();
    
    const [
      totalProducts,
      totalSuppliers,
      lowStockProducts,
      todayInbound,
      todayOutbound
    ] = await Promise.all([
      Product.countDocuments({ status: 'active' }),
      Supplier.countDocuments({ status: 'active' }),
      Product.countDocuments({ 
        status: 'active',
        $expr: { $lte: ['$stock', '$minStock'] }
      }),
      Inbound.countDocuments({
        inboundDate: {
          $gte: new Date(new Date().setHours(0, 0, 0, 0)),
          $lt: new Date(new Date().setHours(23, 59, 59, 999))
        }
      }),
      Outbound.countDocuments({
        outboundDate: {
          $gte: new Date(new Date().setHours(0, 0, 0, 0)),
          $lt: new Date(new Date().setHours(23, 59, 59, 999))
        }
      })
    ]);
    
    return c.json({
      success: true,
      data: {
        totalProducts,
        totalSuppliers,
        lowStockProducts,
        todayInbound,
        todayOutbound
      }
    });
  } catch (error) {
    console.error('获取仪表板数据失败:', error);
    return c.json({ success: false, message: error.message }, 500);
  }
});

// 404处理
app.notFound((c) => {
  return c.json({ message: '接口不存在' }, 404);
});

// 错误处理
app.onError((err, c) => {
  console.error('边缘函数错误:', {
    message: err.message,
    stack: err.stack,
    url: c.req.url,
    method: c.req.method,
    timestamp: new Date().toISOString()
  });
  
  return c.json({ 
    message: '服务器内部错误',
    requestId: crypto.randomUUID()
  }, 500);
});

// 腾讯云函数主处理函数
exports.main_handler = async (event, context) => {
  try {
    // 设置环境变量
    process.env.MONGODB_URI = process.env.MONGODB_URI;
    process.env.NODE_ENV = process.env.NODE_ENV || 'production';
    
    // 构造标准的Request对象
    const url = new URL(event.path || '/', 'https://example.com');
    if (event.queryString) {
      Object.entries(event.queryString).forEach(([key, value]) => {
        url.searchParams.set(key, value);
      });
    }
    
    const request = new Request(url.toString(), {
      method: event.httpMethod || 'GET',
      headers: event.headers || {},
      body: event.body || undefined
    });
    
    // 处理请求
    const response = await app.fetch(request);
    
    // 转换响应格式
    const responseBody = await response.text();
    
    return {
      statusCode: response.status,
      headers: Object.fromEntries(response.headers.entries()),
      body: responseBody,
      isBase64Encoded: false
    };
  } catch (error) {
    console.error('腾讯云函数处理错误:', error);
    return {
      statusCode: 500,
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ 
        message: '服务器内部错误',
        error: error.message 
      }),
      isBase64Encoded: false
    };
  }
};

// 保持连接活跃
async function keepWarm() {
  try {
    if (mongoose.connection.readyState === 1) {
      await mongoose.connection.db.admin().ping();
    }
  } catch (error) {
    console.log('Keep warm ping failed:', error);
  }
}