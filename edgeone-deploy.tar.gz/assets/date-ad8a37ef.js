import{aA as a}from"./element-plus-85aadb0a.js";const f=(r,t="YYYY-MM-DD")=>r?a(r).format(t):"";export{f};
