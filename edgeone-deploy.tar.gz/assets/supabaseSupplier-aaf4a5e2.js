import{s as i}from"./supabase-9027c01f.js";class f{constructor(){this.tableName="suppliers"}async getSuppliers(r={}){try{let e=i.from(this.tableName).select(`
        *,
        supplier_products (
          product_id,
          is_primary,
          products (
            id,
            name,
            category
          )
        )
      `);if(r.search&&(e=e.or(`name.ilike.%${r.search}%,contact.ilike.%${r.search}%,phone.ilike.%${r.search}%`)),r.status&&(e=e.eq("status",r.status)),e=e.order("created_at",{ascending:!1}),r.page&&r.pageSize){const o=(r.page-1)*r.pageSize,s=o+r.pageSize-1;e=e.range(o,s)}const{data:t,error:n}=await e;if(n)throw n;return{success:!0,data:t.map(o=>{var s;return{...o,relatedProducts:((s=o.supplier_products)==null?void 0:s.map(a=>({id:a.products.id,name:a.products.name,category:a.products.category,isPrimary:a.is_primary})))||[]}}),message:"获取供应商列表成功"}}catch(e){throw console.error("获取供应商列表失败:",e),e}}async getSupplierById(r){var e;try{const{data:t,error:n}=await i.from(this.tableName).select(`
          *,
          supplier_products (
            product_id,
            is_primary,
            products (
              id,
              name,
              category
            )
          )
        `).eq("id",r).single();if(n)throw n;return{success:!0,data:{...t,relatedProducts:((e=t.supplier_products)==null?void 0:e.map(o=>({id:o.products.id,name:o.products.name,category:o.products.category,isPrimary:o.is_primary})))||[]},message:"获取供应商详情成功"}}catch(t){throw console.error("获取供应商详情失败:",t),t}}async createSupplier(r){try{this.validateSupplierData(r,!0);const e={name:r.name,contact:r.contact,phone:r.phone,address:r.address||"",payment_method:r.paymentMethod||"",need_invoice:r.needInvoice||!1,status:r.status||"active",notes:r.notes||""},{data:t,error:n}=await i.from(this.tableName).insert([e]).select();if(n)throw n;const c=t[0];if(r.products&&r.products.length>0){const o=r.products.map(a=>({supplier_id:c.id,product_id:a,is_primary:!1})),{error:s}=await i.from("supplier_products").insert(o);s&&console.error("创建供应商-商品关联失败:",s)}return{success:!0,data:c,message:"供应商创建成功"}}catch(e){throw console.error("创建供应商失败:",e),e}}async updateSupplier(r,e){try{this.validateSupplierData(e,!1);const t={};e.name!==void 0&&(t.name=e.name),e.contact!==void 0&&(t.contact=e.contact),e.phone!==void 0&&(t.phone=e.phone),e.address!==void 0&&(t.address=e.address),e.paymentMethod!==void 0&&(t.payment_method=e.paymentMethod),e.needInvoice!==void 0&&(t.need_invoice=e.needInvoice),e.status!==void 0&&(t.status=e.status),e.notes!==void 0&&(t.notes=e.notes);const{data:n,error:c}=await i.from(this.tableName).update(t).eq("id",r).select();if(c)throw c;if(e.products!==void 0){const{data:o,error:s}=await i.from("supplier_products").select("product_id").eq("supplier_id",r);if(s)console.error("获取当前关联失败:",s);else{const a=o.map(d=>d.product_id),u=e.products||[],p=a.filter(d=>!u.includes(d)),m=u.filter(d=>!a.includes(d));if(p.length>0){const{error:d}=await i.from("supplier_products").delete().eq("supplier_id",r).in("product_id",p);d&&console.error("删除旧关联失败:",d)}if(m.length>0){const d=m.map(l=>({supplier_id:r,product_id:l,is_primary:!1})),{error:h}=await i.from("supplier_products").insert(d);h&&console.error("添加新关联失败:",h)}}}return{success:!0,data:n[0],message:"供应商更新成功"}}catch(t){throw console.error("更新供应商失败:",t),t}}async deleteSupplier(r){try{const{error:e}=await i.from(this.tableName).delete().eq("id",r);if(e)throw e;return{success:!0,message:"供应商删除成功"}}catch(e){throw console.error("删除供应商失败:",e),e}}async deleteSuppliers(r){try{const{error:e}=await i.from(this.tableName).delete().in("id",r);if(e)throw e;return{success:!0,message:`成功删除 ${r.length} 个供应商`}}catch(e){throw console.error("批量删除供应商失败:",e),e}}async getSuppliersByProductId(r){try{const{data:e,error:t}=await i.from("supplier_products").select(`
          supplier_id,
          is_primary,
          suppliers (
            id,
            name,
            contact,
            phone,
            status
          )
        `).eq("product_id",r);if(t)throw t;if(!e||e.length===0)return{success:!0,data:[],message:"该商品暂无关联供应商"};const n=e.map(c=>({...c.suppliers,is_primary:c.is_primary})).filter(c=>c&&c.status==="active");return{success:!0,data:n,message:`找到 ${n.length} 个关联供应商`}}catch(e){return console.error("获取商品相关供应商失败:",e),{success:!1,data:[],message:"获取供应商失败: "+e.message}}}async getSupplierStats(){try{const{data:r,error:e}=await i.from(this.tableName).select("*");if(e)throw e;const t=r.length,n=r.filter(s=>s.status==="active").length,c=r.filter(s=>s.status==="inactive").length,o={};return r.forEach(s=>{s.payment_method&&(o[s.payment_method]=(o[s.payment_method]||0)+1)}),{success:!0,data:{totalSuppliers:t,activeSuppliers:n,inactiveSuppliers:c,paymentMethodStats:Object.entries(o).map(([s,a])=>({name:s,count:a}))}}}catch(r){throw console.error("获取供应商统计失败:",r),r}}validateSupplierData(r,e=!0){const t=[];if((e||r.name!==void 0)&&(!r.name||r.name.trim()==="")&&t.push("供应商名称不能为空"),(e||r.contact!==void 0)&&(!r.contact||r.contact.trim()==="")&&t.push("联系人不能为空"),(e||r.phone!==void 0)&&(!r.phone||r.phone.trim()==="")&&t.push("联系电话不能为空"),r.needInvoice!==void 0&&typeof r.needInvoice!="boolean"&&t.push("是否开票必须是布尔值"),r.status!==void 0&&!["active","inactive"].includes(r.status)&&t.push("状态必须是active或inactive"),r.products!==void 0&&(Array.isArray(r.products)?e&&r.products.length===0&&t.push("请至少选择一个商品"):t.push("商品必须是数组")),t.length>0)throw new Error(t.join(", "))}subscribeToSuppliers(r){return i.channel("suppliers").on("postgres_changes",{event:"*",schema:"public",table:this.tableName},r).subscribe()}}const _=new f;export{_ as s};
